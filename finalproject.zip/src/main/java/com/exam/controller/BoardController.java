package com.exam.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.exam.domain.Board;

@Controller
@RequestMapping("/board")
public class BoardController {
	@GetMapping("/list")
	public String list() {
		return "board/list";
	}
	
	@GetMapping("/write")
	public String write() {
		return "board/write";
	}
	
	@PostMapping("/write")
	public String write(@ModelAttribute Board board) {
		System.out.println(board.getbContent());
		return null;
	}
	
	@GetMapping("/read")
	public String read() {
		return null;
	}
	
	@GetMapping("/delete")
	public String delete() {
		return null;
	}
}
