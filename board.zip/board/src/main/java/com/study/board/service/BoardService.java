package com.study.board.service;

import com.study.board.entity.Board;
import com.study.board.repository.BoardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

@Service
public class BoardService {

  @Autowired // 스프링 빈이 알아서 읽어와서 선언문에 주입을 해줌
  private BoardRepository boardRepository;

  //글 작성 처리
  public void write(Board board, MultipartFile file) throws IOException {

    String projectPath = System.getProperty("user.dir") + "\\src\\main\\resources\\static\\files";
    // 프로젝트 경로 설정
    UUID uuid = UUID.randomUUID();
    // 식별자 추가해서 이름 랜덤 설정
    String fileName = uuid + "_" + file.getOriginalFilename();
    // 파일 이름 설정
    File saveFile = new File(projectPath, fileName);
    // 프로젝트 경로에 파일 이름 넣기
    file.transferTo(saveFile);
    // 깨지니까 thorws Exception 추가

    board.setFilename(fileName);
    board.setFilepath("/files/" + fileName);
    // 워크밴치에 넣어주도록 설정함

    boardRepository.save(board);
  }



  //특정 리스트 처리
  public Page<Board> boardList(Pageable pageable) {
    return boardRepository.findAll(pageable);
  }

  public Page<Board> boardSearchList(String searchKeyword, Pageable pageable) {
    return boardRepository.findByTitleContaining(searchKeyword, pageable);
  }

  //특정 게시글 불러오기
  public Board boardView(Integer id) {

    return boardRepository.findById(id).get();
  }

  //특정 게시글 삭제
  public void boardDelete(Integer id) {
    boardRepository.deleteById(id);
  }
}
