package io.netsong7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThymeleafCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
