package io.netsong7.domain;

import lombok.Data;

@Data
public class Member {
	private String num, name, addr;

}
