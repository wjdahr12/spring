package com.wjdahr12.Member.service;

import java.util.Collection;

import com.wjdahr12.Member.MemberPrinter;
import com.wjdahr12.Member.model.Member;
import com.wjdahr12.Member.repository.MemberDao;

public class MemberListPrinter {
	private MemberDao memDao;
	private MemberPrinter printer;
	
	public void setMemDao(MemberDao memDao) {
		this.memDao = memDao;
	}
	public void setPrinter(MemberPrinter printer) {
		this.printer = printer;
	}
	
	public void printAll() {
		Collection<Member> members = memDao.selectAll();
		
		for(Member m: members) {
			printer.print(m);
		}
		System.out.println();
	}
}
