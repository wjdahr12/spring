package com.wjdahr12.Member.service;

import java.util.Date;

import com.wjdahr12.Member.model.Member;
import com.wjdahr12.Member.model.RegisterRequest;
import com.wjdahr12.Member.repository.MemberDao;

public class MemberRegisterService {
	private MemberDao memberDao;
	
	public MemberRegisterService() {}

	public MemberRegisterService(MemberDao memberDao) {
		this.memberDao =  memberDao;
	}
	
	public void regist(RegisterRequest req) {
			// 이름, 이메일, 패스워드, 패스워드 확인 정보가 담겨있음
			// 같은 이메일이 있는지 여부 검사	
		Member member = memberDao.selectByEmail(req.getEmail());
		if(member != null) {
			System.out.println("같은 이메일이 있습니다.");
			return;
		}
		
		Member newMem = new Member(req.getEmail(), req.getName(), req.getPassword(), new Date());
		memberDao.insert(newMem);
		// 요쳥은 여기서 실제 가입음 Dao가 함
	}

}
