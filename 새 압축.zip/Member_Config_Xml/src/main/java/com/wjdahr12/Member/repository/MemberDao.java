package com.wjdahr12.Member.repository;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.wjdahr12.Member.model.Member;

public class MemberDao {
	private Map<String, Member> map = new HashMap<String, Member>();
	// Map은 리스트나 배열처럼 순차적으로 해당 요소 값을 구하지 않고 key를 통해 value를 얻음
	private static long nextId = 0;
	
	public Member selectByEmail(String email) {
		return map.get(email);
		
	}
	
	public Collection<Member> selectAll(){
		return map.values();
		// 모든사람을 다 조회할 수 있는 기능
		
	}
	
	public void insert(Member member) {
		//실제 가입은 여기서
		member.setId(++nextId);
		map.put(member.getEmail(), member);
		System.out.println("test:" + map);
		
	}
	
	public void update(Member member) {
		map.put(member.getEmail(), member);
		System.out.println("수정테스트: " + member.getPassword());
		
	}

}
