package net.netsong7.member.repository;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import net.netsong7.member.model.Member;

@Repository
public class MemberDao {
	private Map<String, Member> map = new HashMap<String, Member>();
	private static long nextId = 0;
	
	
	//한사람 조회기능
	public Member selectByEmail(String email) {
		return map.get(email);
	}
	
	//모든 사람 조회기능
	public Collection<Member> selectAll(){
		return map.values();
	}
	
	//삽입 기능
	public void insert(Member member) {
		member.setId(++nextId);
		map.put(member.getEmail(), member);
		System.out.println("test:" + map);
	}
	
	//수정 기능
	public void update(Member member) {
		map.put(member.getEmail(), member);
		System.out.println("수정테스트 : " + member.getPassword());
	}

}
