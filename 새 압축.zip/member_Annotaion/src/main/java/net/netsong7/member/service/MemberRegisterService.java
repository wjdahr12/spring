package net.netsong7.member.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.netsong7.member.model.Member;
import net.netsong7.member.model.RegisterRequest;
import net.netsong7.member.repository.MemberDao;

@Service("memberRegSvc")
public class MemberRegisterService{
	private MemberDao memberDao;
	
	//기본생성자도 항상 준비
	public MemberRegisterService() {}	
	//위 값을 전달받기 위한 생성자를 생성
	@Autowired
	public MemberRegisterService(MemberDao memberDao) {
		this.memberDao = memberDao;
	}
	
	
	//요청은 Dao가 해주지만 실제서비스는 여기서
	public void regist(RegisterRequest req) {
		//같은 이메일이 있는지 여부 검사		
		Member member = memberDao.selectByEmail(req.getEmail());
		if(member != null) {
			System.out.println("같은 이메일이 있습니다.");
			return;
		}
		
		Member newMem = new Member(req.getEmail(), req.getName(), req.getPassword(), new Date());
		memberDao.insert(newMem);
	}
	

}
