package basic07;

import java.io.IOException;

public interface Outputter {
	void output(String msg) throws IOException;
}
