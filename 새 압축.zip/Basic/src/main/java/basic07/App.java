package basic07;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
	private static ApplicationContext ctx;
					

	public static void main(String[] args) {
		 ctx = new AnnotationConfigApplicationContext(ApplicationContextConfigure.class);
//		ctx2 = new AnnotationConfigApplicationContext("basic06");
				// basic06안에 있는 @~~ -> 딱지가 붙어있는지 없는지 스캐닝해주는 메소드
		 	
		
		
		MessageBean bean = ctx.getBean("getMessageKr", basic07.MessageBean.class);
			// ctx2 안에 있는 빈 가져오기; id값, 어디에 소속되어있는 클래스인지까지 해서
		bean.sayHello();
		
		bean = ctx.getBean("getMessageEn", basic07.MessageBean.class);
		bean.sayHello();
		

	}

}
