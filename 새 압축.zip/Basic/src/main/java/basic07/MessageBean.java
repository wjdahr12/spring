package basic07;

interface MessageBean {
	public void sayHello();

}
