package basic04;

interface MessageBean {
	public void sayHello(String name);

}
