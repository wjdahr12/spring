package basic05;

interface MessageBean {
	public void sayHello();

}
