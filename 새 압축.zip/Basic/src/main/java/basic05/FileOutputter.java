package basic05;

import java.io.FileWriter;
import java.io.IOException;

public class FileOutputter implements Outputter {
	private String filePath;
	
	public void setFilePath(String path) {
		filePath = path;
	}

	@Override
	public void output(String msg) throws IOException {
		// TODO Auto-generated method stub
		FileWriter writer = new FileWriter(filePath);
		writer.write(msg);
		writer.close();

	}

}
