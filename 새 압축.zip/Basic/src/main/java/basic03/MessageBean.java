package basic03;

interface MessageBean {
	public void sayHello(String name);

}
