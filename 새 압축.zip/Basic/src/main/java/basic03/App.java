package basic03;

public class App {

	public static void main(String[] args) {
		MessageBeanFactory factory = MessageBeanFactory.newInstance();
									// 공장이 어디있는지 알아내기
							// newInstance()메소드를 가져와서 MessageBeanFactory 객체 생성
		
		MessageBean bean = factory.createMessage("kr");
		bean.sayHello("홍길동");
		
		bean = factory.createMessage("en");
		bean.sayHello("Tom");

	}

}
