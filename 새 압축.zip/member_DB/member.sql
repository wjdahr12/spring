CREATE TABLE member(
	id number not null,
	email varchar(50) not null PRIMARY KEY,
	name varchar(20) NOT null,
	password varchar(10) not null,
	registerDate date not null
);

drop table member;

CREATE SEQUENCE seq_id;