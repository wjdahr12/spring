package basic06;

interface MessageBean {
	public void sayHello();

}
