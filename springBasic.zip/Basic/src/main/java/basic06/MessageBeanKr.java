package basic06;

import org.springframework.stereotype.Component;

@Component("msgkr")
//@Component // id값을 정하지 않았을 때는 클래스명이 id값이 됨
public class MessageBeanKr implements MessageBean {
	// property 속성에 의해 첫글자가 소문자인 messageBeanKr이 id값이 됨
	// ctx2.getBean() 여기에 들어감
	private String name;
	private int age;
	
	public void setName(String name) {
		this.name = name;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public void sayHello() {
		System.out.println("나의 이름은 " + name + "이고 내 나이는 " + age + "살 입니다.");
	}
}
