package basic07;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
// 이 어노테이션은 xml 설정파일로서의 역할을 하게끔 클래스를 바꿔줌
// @Configurationdl 붙지 않고 @Bean만 설정된다면 싱글톤이 아니게 바뀜
public class ApplicationContextConfigure {
			// 이객체는 다 싱글톤
		
	
	@Bean
	// 이 어노테이션을 사용해서 작동 가능
	public MessageBean getMessageKr() {
					// @Bean을 사용하면 이쪽 메소드명이 id값이 되서 getBean()으로 넘어감
		MessageBeanKr kr = new MessageBeanKr();
		kr.setAge(20);
		kr.setName("신돌석");
		kr.setOutputter(output());
		return kr;
	}
	
	
	@Bean
	public MessageBean getMessageEn() {
		MessageBeanEn en = new MessageBeanEn();
		en.setAge(30);
		en.setName("Tom");
		en.setOutputter(output());
		return en;
	}
	
	@Bean
	public Outputter output() {
		FileOutputter f = new FileOutputter();
		f.setFilePath("c:\\temp\\out.txt");
		return f;
	}

}
