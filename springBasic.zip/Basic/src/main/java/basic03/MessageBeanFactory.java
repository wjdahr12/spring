package basic03;

public class MessageBeanFactory {
	private MessageBeanFactory() {}
	private static MessageBeanFactory factory = 
											new MessageBeanFactory();
	public static MessageBeanFactory newInstance() {
		return factory;
	}
	// 여기까지가 싱글톤 패턴
	
	public MessageBean createMessage(String nation) {
		if(nation.equals("kr")) {
			return new MessageBeanKr();
		}
		else {
			return new MessageBeanEn();
		}
	}
}
