package basic08;

interface MessageBean {
	public void sayHello();

}
