package basic04;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
	private static ApplicationContext ctx;
					// 스프링 클래스를 시작할 수 있는 일종의 메인클래스와 같은 역할을 함
					// 이렇게하면 설정파일을 읽어올 수 있는 토대가 마련됨

	public static void main(String[] args) {
		ctx = new ClassPathXmlApplicationContext("config/basic04_config.xml");
		 	// 클래스패스 스프링 설정파일을 불러오는 메소드; 
			// 여기서의 객체 생성은 스프링 설정파일을 불러오려는 목적이기에 의존성과는 연관이 없음
		
		
		MessageBean bean = ctx.getBean("msgKr", basic04.MessageBean.class);
			// ctx 안에 있는 빈 가져오기; id값, 어디에 소속되어있는 클래스인지까지 해서
		bean.sayHello("홍길동");
		
		bean = ctx.getBean("msgEn", basic04.MessageBean.class);
		bean.sayHello("Tom");
		
		bean = ctx.getBean("mkr", basic04.MessageBean.class);
		bean.sayHello("james");
		
		bean = ctx.getBean("mskr", basic04.MessageBean.class);
		bean.sayHello("bob");
		
		bean = ctx.getBean("kr", basic04.MessageBean.class);
		bean.sayHello("losa");

	}

}
