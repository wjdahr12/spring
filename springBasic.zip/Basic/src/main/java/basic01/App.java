package basic01;

public class App {

	public static void main(String[] args) {
		MessageBean bean = new MessageBean();
		bean.sayHello("홍길동");
//		MessageBean에 의존하는 잘못된 방식
	}

}
